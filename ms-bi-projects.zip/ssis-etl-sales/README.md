# ETL Pipeline – SSIS Project

## 🛠 Overview
An SSIS package to extract sales data from a CSV file, transform the data (cleanup, lookups), and load it into a SQL Server database.

## 🔄 ETL Steps
- Source: `sample_sales_data.csv`
- Transform: Data conversion, null handling, lookups
- Load: SQL Server destination table

## 📁 Files
- `SalesETL.dtsx` – SSIS package file (to be created)
- `/data/sample_sales_data.csv` – Sample source file
- `/screenshots/` – Package design preview

## 💡 Highlights
- Error handling
- Lookup transformations
- Logging and event handlers

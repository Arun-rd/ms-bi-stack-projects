# Financial Report – SSRS

## 📈 Overview
A pixel-perfect financial report built in SSRS with quarterly revenue, profit margins, and comparison charts. Exportable to PDF and Excel.

## 📊 Key Features
- Multi-level parameter filtering
- Charts, matrices, and totals
- Company branding and formatting
- Export to Excel/PDF

## 📁 Files
- `FinancialReport.rdl` – SSRS report file (to be created)
- `/screenshots/` – Report preview images

## 🔧 Tools Used
- SSRS
- Report Builder
- SQL Server as data source

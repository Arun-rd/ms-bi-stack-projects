# Invoice Approval Workflow – Power Automate

## 📄 Overview
A multi-step invoice approval workflow using Power Automate, integrated with Outlook and SharePoint. Automatically routes invoices to approvers with email notifications.

## 🔁 Steps
1. Invoice uploaded to SharePoint
2. Power Automate triggers flow
3. Approval email sent to manager
4. Response logged in SharePoint

## 📁 Files
- `flow_export.zip` – Power Automate flow export (to be added)
- `/flow_screenshots/` – Visual flow steps and logic

## 🔧 Tech Stack
- Power Automate
- SharePoint
- Outlook

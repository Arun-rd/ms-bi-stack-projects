# Leave Request App – Power Apps

## 📝 Overview
A low-code application for employees to request leave, with approval workflow handled through Power Automate and data stored in SharePoint.

## 🔧 Features
- Simple leave request form
- Status tracking (Pending, Approved, Rejected)
- Manager approval flow
- Email notifications using Power Automate

## 🔗 Integrations
- Power Apps
- Power Automate
- SharePoint Lists

## 📸 Screenshots
(Insert screenshots in /app_screenshots folder)

## ⚙️ How It Works
1. Employee fills request in Power Apps
2. Power Automate triggers approval workflow
3. SharePoint stores request data
4. Manager receives email to approve or reject
